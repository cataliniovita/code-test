## DreamFactory PHP Variables
On Ubuntu systems, do the following:

 1. copy the `dreamfactory.ini` file from `config/external/php/etc/php5/mods-available` into your `/etc/php5/mods-available/` directory.
 2. Enable the "mod" by issuing the command `sudo php5enmod dreamfactory`
 3. Restart your web server

## Other OSes
CentOS and Redhat have similar virtual-host setups and you should be able to adapt the included file easily.

### Windows
You're on your own bud.
