<?php return array (
  'dreamfactory/df-apidoc' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\ApiDoc\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-aws' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Aws\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-azure' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Azure\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-cache' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Cache\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-cassandra' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Cassandra\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-core' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\LaravelServiceProvider',
    ),
    'aliases' => 
    array (
      'ServiceManager' => 'DreamFactory\\Core\\Facades\\ServiceManager',
      'SystemTableModelMapper' => 'DreamFactory\\Core\\Facades\\SystemTableModelMapper',
      'DbSchemaExtensions' => 'DreamFactory\\Core\\Facades\\DbSchemaExtensions',
    ),
  ),
  'dreamfactory/df-couchdb' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\CouchDb\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-database' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Database\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-email' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Email\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-exporter-prometheus' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\DreamFactoryPrometheusExporter\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-file' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\File\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-firebird' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Firebird\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-git' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Git\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-graphql' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\GraphQL\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'GraphQL' => 'DreamFactory\\Core\\GraphQL\\Facades\\GraphQL',
    ),
  ),
  'dreamfactory/df-mongo-logs' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\MongoLogs\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-oauth' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\OAuth\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-rackspace' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Rackspace\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-rws' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\Rws\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-sqldb' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\SqlDb\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-system' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\System\\ServiceProvider',
    ),
  ),
  'dreamfactory/df-user' => 
  array (
    'providers' => 
    array (
      0 => 'DreamFactory\\Core\\User\\ServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'graham-campbell/bitbucket' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\Bitbucket\\BitbucketServiceProvider',
    ),
  ),
  'graham-campbell/github' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\GitHub\\GitHubServiceProvider',
    ),
  ),
  'graham-campbell/gitlab' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\GitLab\\GitLabServiceProvider',
    ),
  ),
  'jenssegers/mongodb' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Mongodb\\MongodbServiceProvider',
      1 => 'Jenssegers\\Mongodb\\MongodbQueueServiceProvider',
    ),
  ),
  'laravel/socialite' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'socialiteproviders/manager' => 
  array (
    'providers' => 
    array (
      0 => 'SocialiteProviders\\Manager\\ServiceProvider',
    ),
  ),
  'spatie/laravel-http-logger' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\HttpLogger\\HttpLoggerServiceProvider',
    ),
  ),
  'tymon/jwt-auth' => 
  array (
    'aliases' => 
    array (
      'JWTAuth' => 'Tymon\\JWTAuth\\Facades\\JWTAuth',
      'JWTFactory' => 'Tymon\\JWTAuth\\Facades\\JWTFactory',
    ),
    'providers' => 
    array (
      0 => 'Tymon\\JWTAuth\\Providers\\LaravelServiceProvider',
    ),
  ),
);